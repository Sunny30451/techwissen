#!/usr/bin/env sh
set -eu

echo '== Container =='
docker compose ps

echo
echo '== Nextcloud status =='
docker compose exec -u33 nextcloud php occ status

echo
echo '== Systemkonfiguration (Secrets ausgeblendet) =='
docker compose exec -u33 nextcloud php occ config:list system

echo
echo '== Hintergrundjobs =='
docker compose exec -u33 nextcloud php occ background:cron
