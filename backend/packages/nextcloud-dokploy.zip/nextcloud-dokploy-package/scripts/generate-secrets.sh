#!/usr/bin/env sh
set -eu

printf 'POSTGRES_PASSWORD=%s\n' "$(openssl rand -base64 48 | tr -d '\n')"
printf 'NEXTCLOUD_ADMIN_PASSWORD=%s\n' "$(openssl rand -base64 48 | tr -d '\n')"
