#!/usr/bin/env sh
set -eu

exec docker compose exec -u33 nextcloud php occ "$@"
