# Nextcloud – Dokploy-Paket

Dieses Paket deployt Nextcloud 34 mit PostgreSQL, Redis und einem separaten Cron-Container auf einem Ubuntu-VPS über Dokploy.

## Architektur

```text
Internet
   |
   | HTTPS
   v
Dokploy / Traefik
   |
   v
Nextcloud :80
   |\
   | +--> Redis :6379
   |
   +----> PostgreSQL :5432

Cron --> dieselben Nextcloud-Dateien / dieselbe DB
```

## Sicherheitsprofil

- Keine Host-Port-Freigabe für Nextcloud, PostgreSQL oder Redis.
- Nur `nextcloud:80` wird über Dokploy/Traefik geroutet.
- PostgreSQL und Redis liegen im internen Compose-Netz.
- HTTPS wird in Dokploy aktiviert.
- Secrets gehören in Dokploy Environment/Secrets und nicht ins Git-Repository.

## Empfohlene URL

Am einfachsten ist eine eigene Subdomain:

```text
https://cloud.example.com/
```

Nextcloud unterstützt aber auch einen Reverse-Proxy-Unterpfad:

```text
https://example.com/nextcloud/
```

Für den Unterpfad wird in Dokploy `Strip Path = ON` verwendet. Nextcloud erhält `OVERWRITEWEBROOT=/nextcloud` und erzeugt dadurch weiterhin korrekte öffentliche Links.

## Dokploy-Deployment

1. Repository mit diesem Paket erstellen.
2. In Dokploy eine Docker-Compose-Anwendung erstellen.
3. `docker-compose.yml` auswählen.
4. Environment-Werte aus `.env.example` in Dokploy setzen.
5. Secrets ersetzen.
6. Deploy starten.
7. Domain im Dokploy-Domains-Tab konfigurieren.

### Unterpfad `/nextcloud`

```text
Service:        nextcloud
Container Port: 80
Domain:         example.com
Path:           /nextcloud
Strip Path:     ON
HTTPS:          ON
```

Environment:

```env
NEXTCLOUD_DOMAIN=example.com
NEXTCLOUD_BASE_PATH=/nextcloud
```

### Eigene Subdomain

```text
Service:        nextcloud
Container Port: 80
Domain:         cloud.example.com
Path:           /
Strip Path:     OFF
HTTPS:          ON
```

Environment:

```env
NEXTCLOUD_DOMAIN=cloud.example.com
NEXTCLOUD_BASE_PATH=/
```

## Initiale Zugangsdaten

`NEXTCLOUD_ADMIN_USER` und `NEXTCLOUD_ADMIN_PASSWORD` werden nur für die erste automatische Installation verwendet. Danach das Admin-Passwort innerhalb Nextcloud verwalten.

## Hintergrundjobs

Der Service `cron` führt Nextclouds `/cron.sh` aus und verwendet dasselbe `nextcloud-html`-Volume wie der Webcontainer.

Nach der Installation:

```bash
docker compose exec -u33 nextcloud php occ background:cron
```

## Persistenz und Backup

Sichern:

```text
nextcloud-html
nextcloud-db
```

Redis wird nicht gesichert; es dient als Cache/Locking-Backend.

Vor Updates immer Datenbank und Nextcloud-Volume sichern.

## Update

Der Image-Tag ist bewusst gepinnt:

```env
NEXTCLOUD_IMAGE=nextcloud:34.0.2-apache
```

Für Updates:

1. Backup erstellen.
2. Neue unterstützte Nextcloud-Version auswählen.
3. Image-Tag ändern.
4. Redeploy.
5. Logs und `occ status` prüfen.

Keine Major-Versionen überspringen.

## Prüfen

```bash
./scripts/check-nextcloud.sh
```

oder direkt:

```bash
docker compose exec -u33 nextcloud php occ status
```

## Wichtiger Hinweis zu CalDAV/CardDAV bei Unterpfaden

Nextcloud dokumentiert, dass Service-Discovery-Redirects hinter Reverse Proxies vom Proxy bereitgestellt werden sollten. Bei einer Unterpfad-Installation können daher zusätzliche Redirects für `/.well-known/caldav` und `/.well-known/carddav` erforderlich sein. Eine eigene Subdomain ist deshalb für maximale Client-Kompatibilität die einfachere Variante.
