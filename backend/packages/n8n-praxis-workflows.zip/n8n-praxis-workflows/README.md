# TechWissen – n8n Praxisworkflows mit Ollama

Dieses Paket enthält sechs importierbare n8n-Workflows und einen idempotenten Installer für eine selbst gehostete n8n-Instanz.

## Voraussetzungen

- n8n ist über HTTPS erreichbar.
- n8n ist mit dem externen Docker-Netz `ollama-internal` verbunden.
- Ollama ist aus n8n unter `http://ollama:11434` erreichbar.
- In n8n wurde unter **Settings → n8n API** ein API-Key erzeugt.
- Auf dem Rechner, von dem der Installer läuft, ist Python 3 vorhanden.

## Installation

```bash
export N8N_BASE_URL="https://DOMAIN/n8n"
export N8N_API_KEY="DEIN_N8N_API_KEY"
export OLLAMA_MODEL="gemma3:1b"
export OLLAMA_BASE_URL="http://ollama:11434"
./scripts/install-workflows.sh
```

Der Installer erstellt oder aktualisiert Workflows anhand ihres Namens. Er veröffentlicht sie absichtlich nicht automatisch. Prüfe vor dem Veröffentlichen insbesondere die Authentifizierung der Webhook-Nodes.

## Enthaltene Workflows

1. Ollama-Verbindung prüfen
2. Notizen zusammenfassen
3. E-Mail-Antwortentwurf erzeugen
4. Aufgaben priorisieren
5. Wochenplan erstellen
6. Server-Log analysieren

## Sicherheit

Die JSON-Dateien enthalten keine API-Keys. Die Webhook-Beispiele sind nach dem Import zunächst unveröffentlicht. Konfiguriere vor Veröffentlichung im jeweiligen Webhook-Node eine geeignete Authentifizierung, wenn der Endpoint nicht bewusst öffentlich sein soll.
