#!/usr/bin/env bash
set -euo pipefail
: "${N8N_WEBHOOK_BASE_URL:?z.B. https://example.com/n8n/webhook setzen}"
BASE="${N8N_WEBHOOK_BASE_URL%/}"
post(){ local path="$1"; local json="$2"; echo; echo "=== $path ==="; curl -fsS -X POST "$BASE/$path" -H 'Content-Type: application/json' -d "$json"; echo; }
curl -fsS "$BASE/techwissen-ollama-health"; echo
post techwissen-notizen-zusammenfassen '{"text":"Montag Angebot prüfen. Dienstag Max wegen Termin anrufen. Backup des Servers kontrollieren.","style":"sehr kurz"}'
post techwissen-email-entwurf '{"sender":"Max Mustermann","subject":"Termin nächste Woche","message":"Hallo, passt dir Dienstag um 14 Uhr?","tone":"freundlich und knapp"}'
post techwissen-aufgaben-priorisieren '{"tasks":["Rechnung bezahlen","Serverbackup prüfen","Urlaub buchen","Dokumentation aktualisieren"],"context":"Feierabend, 90 Minuten verfügbar"}'
post techwissen-wochenplan '{"goals":"Sport zweimal; TechWissen-Artikel fertigstellen; Papierkram erledigen","appointments":"Mittwoch 18 Uhr Termin; Freitag 16 Uhr Einkauf","constraints":"werktags abends maximal 2 Stunden"}'
post techwissen-log-analyse '{"service":"nginx","log":"connect() failed (111: Connection refused) while connecting to upstream, upstream: http://backend:3000/api/health"}'
