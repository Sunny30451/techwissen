#!/usr/bin/env bash
set -euo pipefail
node - <<'NODE'
const url = process.env.OLLAMA_BASE_URL || 'http://ollama:11434';
fetch(`${url.replace(/\/$/, '')}/api/tags`)
  .then(async r => { if (!r.ok) throw new Error(`HTTP ${r.status}: ${await r.text()}`); return r.json(); })
  .then(data => { console.log('Ollama erreichbar. Modelle:'); for (const m of data.models || []) console.log(`- ${m.name}`); })
  .catch(err => { console.error('Ollama nicht erreichbar:', err.message); process.exit(1); });
NODE
