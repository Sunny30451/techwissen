#!/usr/bin/env python3
"""Idempotenter Installer für die TechWissen-n8n-Beispielworkflows."""
import argparse, json, os, sys, urllib.request, urllib.parse, urllib.error
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WF_DIR = ROOT / 'workflows'

def env(name, default=None):
    value = os.environ.get(name)
    return value if value not in (None, '') else default

def api(base, key, method, path, payload=None):
    url = base.rstrip('/') + '/api/v1' + path
    data = None if payload is None else json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(url, data=data, method=method, headers={
        'X-N8N-API-KEY': key,
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'User-Agent': 'TechWissen-n8n-Workflow-Installer/1.0',
    })
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            raw = response.read()
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        raise RuntimeError(f'{method} {url} -> HTTP {e.code}: {body[:1000]}') from e
    except urllib.error.URLError as e:
        raise RuntimeError(f'{method} {url} nicht erreichbar: {e}') from e

def list_workflows(base, key):
    all_items=[]
    cursor=None
    while True:
        query={'limit':'250'}
        if cursor: query['cursor']=cursor
        result=api(base,key,'GET','/workflows?'+urllib.parse.urlencode(query))
        items=result.get('data', result if isinstance(result,list) else [])
        all_items.extend(items)
        cursor=result.get('nextCursor') if isinstance(result,dict) else None
        if not cursor: return all_items

def replace(obj, old, new):
    if isinstance(obj,str): return obj.replace(old,new)
    if isinstance(obj,list): return [replace(x,old,new) for x in obj]
    if isinstance(obj,dict): return {k:replace(v,old,new) for k,v in obj.items()}
    return obj

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--base-url', default=env('N8N_BASE_URL'), help='z.B. https://example.com/n8n')
    p.add_argument('--api-key', default=env('N8N_API_KEY'))
    p.add_argument('--ollama-url', default=env('OLLAMA_BASE_URL','http://ollama:11434'))
    p.add_argument('--ollama-model', default=env('OLLAMA_MODEL','gemma3:1b'))
    p.add_argument('--project-id', default=env('N8N_PROJECT_ID'))
    p.add_argument('--dry-run', action='store_true')
    args=p.parse_args()
    if not args.base_url or not args.api_key:
        p.error('N8N_BASE_URL und N8N_API_KEY müssen gesetzt sein.')
    if not args.base_url.startswith(('http://','https://')):
        p.error('N8N_BASE_URL muss die vollständige externe n8n-Basis-URL sein.')

    existing={w.get('name'):w for w in list_workflows(args.base_url,args.api_key)}
    created=updated=0
    for file in sorted(WF_DIR.glob('*.json')):
        data=json.loads(file.read_text(encoding='utf-8'))
        data=replace(data,'__OLLAMA_BASE_URL__',args.ollama_url.rstrip('/'))
        data=replace(data,'__OLLAMA_MODEL__',args.ollama_model)
        payload={k:data[k] for k in ('name','nodes','connections','settings') if k in data}
        if args.project_id and data['name'] not in existing:
            payload['projectId']=args.project_id
        current=existing.get(data['name'])
        if args.dry_run:
            print(('UPDATE' if current else 'CREATE'), data['name'])
            continue
        if current:
            wid=current['id']
            api(args.base_url,args.api_key,'PUT',f'/workflows/{wid}',payload)
            updated+=1
            print(f'aktualisiert: {data["name"]} ({wid})')
        else:
            result=api(args.base_url,args.api_key,'POST','/workflows',payload)
            created+=1
            print(f'angelegt:     {data["name"]} ({result.get("id","?")})')
    print(f'Fertig. Angelegt: {created}, aktualisiert: {updated}.')
    print('Die Workflows bleiben absichtlich unveröffentlicht. Webhook-Authentifizierung konfigurieren und danach in n8n veröffentlichen.')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(f'FEHLER: {exc}', file=sys.stderr)
        sys.exit(1)
