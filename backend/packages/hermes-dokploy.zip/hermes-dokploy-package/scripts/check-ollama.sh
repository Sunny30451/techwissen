#!/usr/bin/env sh
set -eu
CONTAINER="${1:-hermes}"
docker exec "$CONTAINER" sh -lc 'curl -fsS http://ollama:11434/v1/models | head -c 1000'
printf '\n'
