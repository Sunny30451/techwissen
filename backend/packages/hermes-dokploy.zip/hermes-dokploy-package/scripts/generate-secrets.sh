#!/usr/bin/env sh
set -eu
printf 'HERMES_DASHBOARD_BASIC_AUTH_SECRET=%s\n' "$(openssl rand -base64 48 | tr -d '\n')"
printf 'API_SERVER_KEY=%s\n' "$(openssl rand -hex 32)"
