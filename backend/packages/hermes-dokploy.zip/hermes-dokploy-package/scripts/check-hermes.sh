#!/usr/bin/env sh
set -eu
CONTAINER="${1:-hermes}"
docker exec "$CONTAINER" hermes version
docker exec "$CONTAINER" hermes gateway status || true
