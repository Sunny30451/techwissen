# Hermes Agent – Dokploy-Paket

Dieses Paket deployt Nous Research Hermes Agent als persistenten Docker-Container auf einem Dokploy-Host.

## Sicherheitsprofil

- Keine Host-Ports im Basis-Compose.
- Persistenz über `hermes-data:/opt/data`.
- Dashboard standardmäßig deaktiviert.
- API-Server standardmäßig deaktiviert.
- Öffentliches Dashboard nur mit geeigneter Authentifizierung; für Internet-Zugriff empfiehlt Hermes OAuth.
- Optionaler Zugriff auf das bestehende interne Ollama-Netz `ollama-internal`.

## Basisdeployment

1. `.env.example` als Vorlage für Dokploy Environment Settings verwenden.
2. `docker-compose.yml` deployen.
3. Im Dokploy-Terminal des Containers einmalig `hermes setup` oder `hermes model` ausführen.
4. Danach Gateway-Status prüfen.

## Ollama verwenden

Voraussetzung: Docker-Netz `ollama-internal` existiert und Ollama ist dort unter `http://ollama:11434` erreichbar.

In Dokploy als Compose-Dateien zusammen verwenden:

```bash
docker compose -f docker-compose.yml -f docker-compose.ollama.yml up -d
```

Hermes Custom Endpoint:

```text
http://ollama:11434/v1
```

Hermes verlangt für Agent-Betrieb mindestens 64k Kontext. Das Ollama-Paket muss daher z. B. mit `OLLAMA_CONTEXT_LENGTH=64000` laufen.

## Dashboard per SSH-Tunnel

Die sicherste einfache Remote-Variante ist das localhost-only Host-Mapping:

```bash
docker compose -f docker-compose.yml -f docker-compose.ssh-dashboard.yml up -d
```

Danach vom lokalen Rechner:

```bash
ssh -N -L 19119:127.0.0.1:19119 USER@VPS
```

Browser:

```text
http://127.0.0.1:19119
```

## Dashboard öffentlich über Dokploy

Nur mit OAuth/OIDC empfehlen. In Dokploy auf `hermes:9119` routen. Bei einem Pfadprefix wie `/hermes` muss der Reverse Proxy den Prefix entfernen und als `X-Forwarded-Prefix` weiterreichen. Hermes unterstützt dieses Muster.

Empfehlung für Dokploy:

```text
Service:        hermes
Container Port: 9119
Path:           /hermes
Strip Path:     ON
HTTPS:          ON
```

Zusätzlich:

```env
HERMES_DASHBOARD=1
HERMES_DASHBOARD_HOST=0.0.0.0
HERMES_DASHBOARD_OAUTH_CLIENT_ID=agent:...
HERMES_DASHBOARD_PUBLIC_URL=https://DOMAIN/hermes
```

Für eine Internet-Freigabe zuerst im Container `hermes dashboard register --redirect-uri https://DOMAIN/hermes/auth/callback` ausführen.

## Backup

Das Named Volume `hermes-data` enthält Konfiguration, Schlüssel, Sessions, Skills und Memory und muss gesichert werden.
