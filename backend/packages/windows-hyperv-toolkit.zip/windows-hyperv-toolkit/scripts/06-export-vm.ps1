#Requires -RunAsAdministrator
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,
    [Parameter(Mandatory = $true)]
    [string]$ExportPath
)

$ErrorActionPreference = 'Stop'

if (-not (Get-VM -Name $VMName -ErrorAction SilentlyContinue)) {
    throw "VM '$VMName' existiert nicht."
}

New-Item -ItemType Directory -Force -Path $ExportPath | Out-Null
Export-VM -Name $VMName -Path $ExportPath
Write-Host "VM '$VMName' wurde nach '$ExportPath' exportiert." -ForegroundColor Green
