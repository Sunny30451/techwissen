#Requires -RunAsAdministrator
param(
    [string]$SwitchName = 'VM-NAT',
    [string]$NatName = 'VM-NAT',
    [string]$GatewayIPAddress = '192.168.100.1',
    [int]$PrefixLength = 24,
    [string]$NetworkPrefix = '192.168.100.0/24'
)

$ErrorActionPreference = 'Stop'

if (-not (Get-VMSwitch -Name $SwitchName -ErrorAction SilentlyContinue)) {
    New-VMSwitch -Name $SwitchName -SwitchType Internal | Out-Null
    Write-Host "Internal Switch '$SwitchName' erstellt." -ForegroundColor Green
} else {
    Write-Host "Switch '$SwitchName' existiert bereits." -ForegroundColor Yellow
}

$alias = "vEthernet ($SwitchName)"
$existingIp = Get-NetIPAddress -InterfaceAlias $alias -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -eq $GatewayIPAddress }

if (-not $existingIp) {
    New-NetIPAddress -IPAddress $GatewayIPAddress -PrefixLength $PrefixLength -InterfaceAlias $alias | Out-Null
    Write-Host "Gateway $GatewayIPAddress/$PrefixLength auf '$alias' gesetzt." -ForegroundColor Green
}

if (-not (Get-NetNat -Name $NatName -ErrorAction SilentlyContinue)) {
    New-NetNat -Name $NatName -InternalIPInterfaceAddressPrefix $NetworkPrefix | Out-Null
    Write-Host "NAT '$NatName' für $NetworkPrefix erstellt." -ForegroundColor Green
} else {
    Write-Host "NAT '$NatName' existiert bereits." -ForegroundColor Yellow
}

Write-Host ''
Get-VMSwitch -Name $SwitchName
Get-NetNat -Name $NatName
