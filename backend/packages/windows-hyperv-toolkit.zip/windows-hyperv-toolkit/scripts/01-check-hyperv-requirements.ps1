#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

Write-Host '=== Hyper-V Host Check ===' -ForegroundColor Cyan
Write-Host "Computer: $env:COMPUTERNAME"
Write-Host "Windows:  $([System.Environment]::OSVersion.VersionString)"
Write-Host ''

Write-Host '--- systeminfo / Hyper-V Requirements ---' -ForegroundColor Yellow
systeminfo.exe | Select-String -Pattern 'Hyper-V|Hypervisor|Virtualisierung|Virtualization|Second Level|SLAT|VM Monitor|Data Execution'

Write-Host ''
Write-Host '--- Hyper-V Role ---' -ForegroundColor Yellow
$feature = Get-WindowsFeature -Name Hyper-V -ErrorAction SilentlyContinue
if ($feature) {
    $feature | Format-Table DisplayName, Name, InstallState -AutoSize
} else {
    Write-Warning 'Get-WindowsFeature ist nicht verfügbar oder Hyper-V wurde nicht gefunden.'
}

Write-Host ''
Write-Host 'Hinweis: Auf einem normalen Contabo VPS ist Nested Virtualization nicht verfügbar.' -ForegroundColor Yellow
Write-Host 'Für Windows Hyper-V bei Contabo wird ein Dedicated Server empfohlen.' -ForegroundColor Yellow
