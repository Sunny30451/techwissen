#Requires -RunAsAdministrator
$ErrorActionPreference = 'Stop'

$feature = Get-WindowsFeature -Name Hyper-V
if ($feature.InstallState -eq 'Installed') {
    Write-Host 'Hyper-V ist bereits installiert.' -ForegroundColor Green
    exit 0
}

Write-Host 'Installiere Hyper-V und Management Tools. Der Server wird anschließend neu gestartet.' -ForegroundColor Cyan
Install-WindowsFeature -Name Hyper-V -IncludeManagementTools -Restart
