#Requires -RunAsAdministrator
param(
    [string]$NatName = 'VM-NAT',
    [ValidateSet('TCP','UDP')]
    [string]$Protocol = 'TCP',
    [Parameter(Mandatory = $true)]
    [UInt16]$ExternalPort,
    [Parameter(Mandatory = $true)]
    [string]$InternalIPAddress,
    [Parameter(Mandatory = $true)]
    [UInt16]$InternalPort,
    [string]$ExternalIPAddress = '0.0.0.0/0',
    [string]$RemoteExternalIPAddressPrefix = ''
)

$ErrorActionPreference = 'Stop'

if (-not (Get-NetNat -Name $NatName -ErrorAction SilentlyContinue)) {
    throw "NAT '$NatName' existiert nicht."
}

$params = @{
    NatName = $NatName
    Protocol = $Protocol
    ExternalIPAddress = $ExternalIPAddress
    ExternalPort = $ExternalPort
    InternalIPAddress = $InternalIPAddress
    InternalPort = $InternalPort
}

if ($RemoteExternalIPAddressPrefix) {
    $params.RemoteExternalIPAddressPrefix = $RemoteExternalIPAddressPrefix
}

Add-NetNatStaticMapping @params

$ruleName = "Hyper-V NAT $Protocol $ExternalPort -> $InternalIPAddress`:$InternalPort"
if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule `
        -DisplayName $ruleName `
        -Direction Inbound `
        -Protocol $Protocol `
        -LocalPort $ExternalPort `
        -Action Allow | Out-Null
}

Write-Host 'Portweiterleitung erstellt:' -ForegroundColor Green
Get-NetNatStaticMapping -NatName $NatName |
    Where-Object { $_.ExternalPort -eq $ExternalPort }
