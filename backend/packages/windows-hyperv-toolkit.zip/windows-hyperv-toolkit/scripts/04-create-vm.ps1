#Requires -RunAsAdministrator
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [string]$SwitchName = 'VM-NAT',
    [string]$VmRoot = 'D:\Hyper-V',
    [int]$MemoryGB = 4,
    [int]$MinimumMemoryGB = 2,
    [int]$MaximumMemoryGB = 8,
    [int]$ProcessorCount = 2,
    [int]$VhdSizeGB = 80,
    [string]$IsoPath = ''
)

$ErrorActionPreference = 'Stop'

if (Get-VM -Name $VMName -ErrorAction SilentlyContinue) {
    throw "Eine VM mit dem Namen '$VMName' existiert bereits."
}

if (-not (Get-VMSwitch -Name $SwitchName -ErrorAction SilentlyContinue)) {
    throw "Hyper-V Switch '$SwitchName' existiert nicht."
}

$vmPath = Join-Path $VmRoot "Virtual Machines\$VMName"
$vhdPath = Join-Path $VmRoot "Virtual Hard Disks\$VMName.vhdx"

New-Item -ItemType Directory -Force -Path (Split-Path $vhdPath) | Out-Null
New-Item -ItemType Directory -Force -Path $vmPath | Out-Null

New-VM `
    -Name $VMName `
    -Generation 2 `
    -MemoryStartupBytes ($MemoryGB * 1GB) `
    -NewVHDPath $vhdPath `
    -NewVHDSizeBytes ($VhdSizeGB * 1GB) `
    -SwitchName $SwitchName `
    -Path $vmPath | Out-Null

Set-VMProcessor -VMName $VMName -Count $ProcessorCount
Set-VMMemory `
    -VMName $VMName `
    -DynamicMemoryEnabled $true `
    -MinimumBytes ($MinimumMemoryGB * 1GB) `
    -StartupBytes ($MemoryGB * 1GB) `
    -MaximumBytes ($MaximumMemoryGB * 1GB)

if ($IsoPath) {
    if (-not (Test-Path $IsoPath)) {
        throw "ISO wurde nicht gefunden: $IsoPath"
    }

    Add-VMDvdDrive -VMName $VMName -Path $IsoPath
    $dvd = Get-VMDvdDrive -VMName $VMName
    Set-VMFirmware -VMName $VMName -FirstBootDevice $dvd
}

Write-Host "VM '$VMName' wurde erstellt." -ForegroundColor Green
Get-VM -Name $VMName | Format-Table Name, State, ProcessorCount, MemoryStartup -AutoSize
Write-Host "Starte mit: Start-VM '$VMName'"
