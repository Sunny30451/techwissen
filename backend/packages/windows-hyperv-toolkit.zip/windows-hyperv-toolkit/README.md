# Windows Hyper-V Toolkit für Contabo

Dieses Paket ergänzt den TechWissen-Artikel **Windows Hyper-V und virtuelle Maschinen auf Contabo einrichten**.

## Voraussetzung

Die Scripts müssen in einer **PowerShell als Administrator** auf einem geeigneten Windows-Hyper-V-Host ausgeführt werden.

Für Contabo gilt: Ein normaler VPS unterstützt keine Nested Virtualization. Für einen Windows-Hyper-V-Host wird ein Dedicated Server empfohlen.

## Reihenfolge

```powershell
.\scripts\01-check-hyperv-requirements.ps1
.\scripts\02-install-hyperv.ps1
```

Nach dem Neustart:

```powershell
.\scripts\03-create-nat-network.ps1
```

Danach beispielsweise:

```powershell
.\scripts\04-create-vm.ps1 `
  -VMName "VM-WIN01" `
  -IsoPath "D:\Hyper-V\ISO\WindowsServer.iso"
```

Optional Portweiterleitung:

```powershell
.\scripts\05-add-port-forward.ps1 `
  -ExternalPort 8443 `
  -InternalIPAddress "192.168.100.10" `
  -InternalPort 443
```

Backup/Export:

```powershell
.\scripts\06-export-vm.ps1 -VMName "VM-WIN01" -ExportPath "E:\Hyper-V-Backups"
```

Vor produktiver Verwendung Parameter und Firewall-Regeln an die eigene Umgebung anpassen.
